/* Accessible navigation, a progressively enhanced menu, and a native-dialog gallery. */
'use strict';

const header = document.querySelector('.header');
const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
const navLinks = [...nav.querySelectorAll('a')];

function closeMenu(returnFocus = false) {
  toggle.setAttribute('aria-expanded', 'false');
  toggle.setAttribute('aria-label', 'Open navigation');
  nav.classList.remove('open');
  header.classList.remove('menu-active');
  document.body.classList.remove('menu-open');
  if (returnFocus) toggle.focus();
}

toggle.addEventListener('click', () => {
  const isOpen = toggle.getAttribute('aria-expanded') === 'true';
  if (isOpen) return closeMenu();
  toggle.setAttribute('aria-expanded', 'true');
  toggle.setAttribute('aria-label', 'Close navigation');
  nav.classList.add('open');
  header.classList.add('menu-active');
  document.body.classList.add('menu-open');
});

navLinks.forEach(link => link.addEventListener('click', () => closeMenu()));
document.addEventListener('keydown', event => {
  if (event.key === 'Escape' && nav.classList.contains('open')) closeMenu(true);
});
document.addEventListener('click', event => {
  if (nav.classList.contains('open') && !header.contains(event.target)) closeMenu();
});
window.matchMedia('(min-width: 768px)').addEventListener('change', event => {
  if (event.matches) closeMenu();
});

let scrollPending = false;
function updateHeader() {
  header.classList.toggle('scrolled', window.scrollY > 30);
  scrollPending = false;
}
window.addEventListener('scroll', () => {
  if (!scrollPending) {
    scrollPending = true;
    requestAnimationFrame(updateHeader);
  }
}, { passive: true });
updateHeader();

// Keep all prices in the HTML for search engines, no-JS visitors, and printing.
const tabList = document.querySelector('.price-tabs');
const priceTabs = [...document.querySelectorAll('[data-price-tab]')];
const pricePanels = [...document.querySelectorAll('[data-price-panel]')];
function selectPrice(category, moveFocus = false) {
  priceTabs.forEach(tab => {
    const selected = tab.dataset.priceTab === category;
    tab.setAttribute('aria-selected', String(selected));
    tab.tabIndex = selected ? 0 : -1;
    if (selected && moveFocus) tab.focus();
  });
  pricePanels.forEach(panel => { panel.hidden = panel.dataset.pricePanel !== category; });
}
if (priceTabs.length && pricePanels.length) {
  tabList.hidden = false;
  tabList.setAttribute('role', 'tablist');
  document.querySelector('#price-content').classList.add('js-menu');
  priceTabs.forEach((tab, index) => {
    const category = tab.dataset.priceTab;
    tab.id = `tab-${category}`;
    tab.setAttribute('role', 'tab');
    tab.setAttribute('aria-controls', `panel-${category}`);
    tab.addEventListener('click', () => selectPrice(category));
    tab.addEventListener('keydown', event => {
      let next;
      if (event.key === 'ArrowRight') next = (index + 1) % priceTabs.length;
      if (event.key === 'ArrowLeft') next = (index - 1 + priceTabs.length) % priceTabs.length;
      if (event.key === 'Home') next = 0;
      if (event.key === 'End') next = priceTabs.length - 1;
      if (next !== undefined) {
        event.preventDefault();
        selectPrice(priceTabs[next].dataset.priceTab, true);
      }
    });
  });
  pricePanels.forEach(panel => {
    panel.id = `panel-${panel.dataset.pricePanel}`;
    panel.setAttribute('role', 'tabpanel');
    panel.setAttribute('aria-labelledby', `tab-${panel.dataset.pricePanel}`);
    panel.tabIndex = 0;
  });
  selectPrice('nails');
  document.querySelectorAll('[data-price-link]').forEach(link => {
    link.addEventListener('click', () => selectPrice(link.dataset.priceLink));
  });
}

// Reveal once; reduced-motion visitors get the complete, static composition.
if ('IntersectionObserver' in window) {
  if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    document.documentElement.classList.add('motion-ready');
    const reveals = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          reveals.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08 });
    document.querySelectorAll('.reveal').forEach(element => reveals.observe(element));
  }
  const sectionObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        navLinks.forEach(link => {
          const active = link.getAttribute('href') === `#${entry.target.id}`;
          link.classList.toggle('active', active);
          if (active) link.setAttribute('aria-current', 'location');
          else link.removeAttribute('aria-current');
        });
      }
    });
  }, { rootMargin: '-15% 0px -65% 0px' });
  document.querySelectorAll('main section[id]').forEach(section => sectionObserver.observe(section));
}

// Native dialog handles focus trapping, Escape, and restoration to the gallery.
const lightbox = document.querySelector('.lightbox');
const gallery = [...document.querySelectorAll('.gallery-item')];
let currentImage = 0;
function showImage(index) {
  currentImage = (index + gallery.length) % gallery.length;
  const item = gallery[currentImage];
  const picture = lightbox.querySelector('figure img');
  picture.src = item.href;
  picture.alt = item.querySelector('img').alt;
  document.querySelector('#lightbox-caption').textContent = item.dataset.caption;
  lightbox.querySelector('.lightbox-counter').textContent = `${currentImage + 1} / ${gallery.length}`;
}
if (typeof lightbox.showModal === 'function') {
  gallery.forEach((item, index) => item.addEventListener('click', event => {
    event.preventDefault();
    showImage(index);
    lightbox.showModal();
    document.body.classList.add('lightbox-open');
  }));
  lightbox.querySelector('.lightbox-close').addEventListener('click', () => lightbox.close());
  lightbox.querySelector('.lightbox-prev').addEventListener('click', () => showImage(currentImage - 1));
  lightbox.querySelector('.lightbox-next').addEventListener('click', () => showImage(currentImage + 1));
  lightbox.addEventListener('click', event => { if (event.target === lightbox) lightbox.close(); });
  lightbox.addEventListener('keydown', event => {
    if (event.key === 'ArrowRight') { event.preventDefault(); showImage(currentImage + 1); }
    if (event.key === 'ArrowLeft') { event.preventDefault(); showImage(currentImage - 1); }
  });
  lightbox.addEventListener('close', () => document.body.classList.remove('lightbox-open'));
}
